#pragma once
void filter(double* in, int sizein, double* out, double bandwidth, double transitionwidth, int type);