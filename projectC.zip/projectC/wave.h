#pragma once
double wave(int index, double frequency1, double frequency2, int type);
double adbssr(double a, double d, double b, double s1, double s2, double r, double index, double start, double sustainvalue, int samplerate);